# Вариант 2
library(shiny)
library(dplyr)
library(ggplot2)
library(tidyverse)

data = read.csv("~/shared/minor2_2020/4-Project/hw-shiny/TA.csv")



ui <- fluidPage(
  
  titlePanel("TA Assesment"),
  
  sidebarLayout(
    sidebarPanel(selectInput("Instructor", "Instructor:",
                             sort(unique(data$Instructor)), selected = c("Instructor_1", "Instructor_7"), multiple = TRUE),
                 
                 sliderInput("Size",
                             "Class size:",
                             min = 0,
                             max = 70,
                             value = c(30, 50))
    ),
    
    mainPanel(
      plotOutput("distPlot")
    )
  )
)

server <- function(input, output) {
  
  output$distPlot <- renderPlot({
    ggplot(data = data) + geom_histogram(aes(x = Score), stat="count") +
      xlab("Score") +
      ylab("count")
  })
}

shinyApp(ui, server)
